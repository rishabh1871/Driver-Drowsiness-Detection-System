# Driver-Drowsiness-Detection
Driver drowsiness detection using OpenCV and Dlib is a computer vision-based system that uses a camera to detect signs of driver fatigue. It analyzes facial features and eye movements using OpenCV and Dlib libraries, triggers alerts if drowsiness is detected, and prevents accidents caused by inattention.
